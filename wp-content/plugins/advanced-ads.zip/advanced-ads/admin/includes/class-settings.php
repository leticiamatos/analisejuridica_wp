<?php
defined( 'ABSPATH'  ) || exit;

class Advanced_Ads_Admin_Settings {
	/**
	 * Instance of this class.
	 *
	 * @var      object
	 */
	protected static $instance = null;

	private function __construct() {
		// settings handling
		add_action( 'admin_init', array( $this, 'settings_init' ) );
	}

	/**
	 * Return an instance of this class.
	 *
	 * @return    object    A single instance of this class.
	 */
	public static function get_instance() {
		// If the single instance hasn't been set, set it now.
		if ( null == self::$instance ) {
			self::$instance = new self;
		}

		return self::$instance;
	}

	/**
	 * initialize settings
	 *
	 * @since 1.0.1
	 */
	public function settings_init(){

		// get settings page hook
		$hook = Advanced_Ads_Admin::get_instance()->plugin_screen_hook_suffix;

		// register settings
		register_setting( ADVADS_SLUG, ADVADS_SLUG, array($this, 'sanitize_settings') );

		// general settings section
		add_settings_section(
			'advanced_ads_setting_section',
			__( 'General', 'advanced-ads' ),
			array($this, 'render_settings_section_callback'),
			$hook
		);

		// licenses section only for main blog
		if( is_main_site( get_current_blog_id() ) ){
		    // register license settings
		    register_setting( ADVADS_SLUG . '-licenses', ADVADS_SLUG . '-licenses' );

		    add_settings_section(
			    'advanced_ads_settings_license_section',
			    __( 'Licenses', 'advanced-ads' ),
			    array($this, 'render_settings_licenses_section_callback'),
			    'advanced-ads-settings-license-page'
		    );

		    add_filter( 'advanced-ads-setting-tabs', array( $this, 'license_tab') );
		}

		// add setting fields to disable ads
		add_settings_field(
			'disable-ads',
			__( 'Disable ads', 'advanced-ads' ),
			array($this, 'render_settings_disable_ads'),
			$hook,
			'advanced_ads_setting_section'
		);
		// add setting fields for user role
		add_settings_field(
			'hide-for-user-role',
			__( 'Hide ads for logged in users', 'advanced-ads' ),
			array($this, 'render_settings_hide_for_users'),
			$hook,
			'advanced_ads_setting_section'
		);
		// add setting fields for advanced js
		add_settings_field(
			'activate-advanced-js',
			__( 'Use advanced JavaScript', 'advanced-ads' ),
			array($this, 'render_settings_advanced_js'),
			$hook,
			'advanced_ads_setting_section'
		);
		// add setting fields for content injection protection
		add_settings_field(
			'content-injection-everywhere',
			__( 'Unlimited ad injection', 'advanced-ads' ),
			array($this, 'render_settings_content_injection_everywhere'),
			$hook,
			'advanced_ads_setting_section'
		);
		// add setting fields for content injection priority
		add_settings_field(
			'content-injection-priority',
			__( 'Priority of content injection filter', 'advanced-ads' ),
			array($this, 'render_settings_content_injection_priority'),
			$hook,
			'advanced_ads_setting_section'
		);
		// add setting fields for content injection priority
		add_settings_field(
			'block-bots',
			__( 'Hide ads from bots', 'advanced-ads' ),
			array($this, 'render_settings_block_bots'),
			$hook,
			'advanced_ads_setting_section'
		);
		// opt out from internal notices
		add_settings_field(
			'disable-notices',
			__( 'Disable notices', 'advanced-ads' ),
			array($this, 'render_settings_disabled_notices'),
			$hook,
			'advanced_ads_setting_section'
		);
		// opt out from internal notices
		add_settings_field(
			'front-prefix',
			__( 'ID prefix', 'advanced-ads' ),
			array($this, 'render_settings_front_prefix'),
			$hook,
			'advanced_ads_setting_section'
		);
		// remove id from widgets
		add_settings_field(
			'remove-widget-id',
			__( 'Remove Widget ID', 'advanced-ads' ),
			array($this, 'render_settings_remove_widget_id'),
			$hook,
			'advanced_ads_setting_section'
		);
		// allow editors to manage ads
		add_settings_field(
			'editors-manage-ads',
			__( 'Allow editors to manage ads', 'advanced-ads' ),
			array($this, 'render_settings_editors_manage_ads'),
			$hook,
			'advanced_ads_setting_section'
		);

		add_settings_field(
			'add-custom-label',
			__( 'Ad label', 'advanced-ads' ),
			array( $this, 'render_settings_add_custom_label' ),
			$hook,
			'advanced_ads_setting_section'
		);

		// only for main blog
		if ( is_main_site( get_current_blog_id() ) ) {
			add_settings_field(
				'uninstall-delete-data',
				__( 'Delete data on uninstall', 'advanced-ads' ),
				array( $this, 'render_settings_uninstall_delete_data' ),
				$hook,
				'advanced_ads_setting_section'
			);
		}

		// hook for additional settings from add-ons
		do_action( 'advanced-ads-settings-init', $hook );
	}

	/**
	 * add license tab
	 *
	 * arr $tabs setting tabs
	 */
	public function license_tab( array $tabs ){

		$tabs['licenses'] = array(
			'page' => 'advanced-ads-settings-license-page',
			'group' => ADVADS_SLUG . '-licenses',
			'tabid' => 'licenses',
			'title' => __( 'Licenses', 'advanced-ads' )
		);

		return $tabs;
	}

	/**
	 * render settings section
	 *
	 * @since 1.1.1
	 */
	public function render_settings_section_callback(){
		// for whatever purpose there might come
	}

	/**
	 * render licenses settings section
	 *
	 * @since 1.5.1
	 */
	public function render_settings_licenses_section_callback(){
		echo '<p>'. __( 'Enter license keys for our powerful <a href="'.ADVADS_URL.'add-ons/#utm_source=advanced-ads&utm_medium=link&utm_campaign=settings-licenses" target="_blank">add-ons</a>.', 'advanced-ads' );
		echo ' ' . __( 'See also <a href="'.ADVADS_URL.'manual-category/purchase-licenses/#utm_source=advanced-ads&utm_medium=link&utm_campaign=settings-licenses" target="_blank">Issues and questions about licenses</a>', 'advanced-ads' ) .'.</p>';
		// nonce field
		echo '<input type="hidden" id="advads-licenses-ajax-referrer" value="' . wp_create_nonce( "advads_ajax_license_nonce" ) . '"/>';
	}

	/**
	 * options to disable ads
	 *
	 * @since 1.3.11
	 */
	public function render_settings_disable_ads(){
		$options = Advanced_Ads::get_instance()->options();

		// set the variables
		$disable_all = isset($options['disabled-ads']['all']) ? 1 : 0;
		$disable_404 = isset($options['disabled-ads']['404']) ? 1 : 0;
		$disable_archives = isset($options['disabled-ads']['archives']) ? 1 : 0;
		$disable_secondary = isset($options['disabled-ads']['secondary']) ? 1 : 0;
		$disable_feed = ( ! isset( $options['disabled-ads']['feed'] ) || $options['disabled-ads']['feed'] ) ? 1 : 0;

		// load the template
		include ADVADS_BASE_PATH . 'admin/views/settings-disable-ads.php';
	}

	/**
	 * render setting to hide ads from logged in users
	 *
	 * @since 1.1.1
	 */
	public function render_settings_hide_for_users(){
		$options = Advanced_Ads::get_instance()->options();
		$current_capability_role = isset($options['hide-for-user-role']) ? $options['hide-for-user-role'] : 0;

		$capability_roles = array(
		'' => __( '(display to all)', 'advanced-ads' ),
		'read' => __( 'Subscriber', 'advanced-ads' ),
		'delete_posts' => __( 'Contributor', 'advanced-ads' ),
		'edit_posts' => __( 'Author', 'advanced-ads' ),
		'edit_pages' => __( 'Editor', 'advanced-ads' ),
		'activate_plugins' => __( 'Admin', 'advanced-ads' ),
		);
		echo '<select name="'.ADVADS_SLUG.'[hide-for-user-role]">';
		foreach ( $capability_roles as $_capability => $_role ) {
			echo '<option value="'.$_capability.'" '.selected( $_capability, $current_capability_role, false ).'>'.$_role.'</option>';
		}
		echo '</select>';

		echo '<p class="description">'. __( 'Choose the lowest role a user must have in order to not see any ads.', 'advanced-ads' ) .'</p>';
	}

	/**
	 * render setting to display advanced js file
	 *
	 * @since 1.2.3
	 */
	public function render_settings_advanced_js(){
		$options = Advanced_Ads::get_instance()->options();
		$checked = ( ! empty($options['advanced-js'])) ? 1 : 0;

		// display notice if js file was overridden
		if( ! $checked && apply_filters( 'advanced-ads-activate-advanced-js', $checked ) ){
			echo '<p>' . __( '<strong>notice: </strong>the file is currently enabled by an add-on that needs it.', 'advanced-ads' ) . '</p>';
		}
		echo '<input id="advanced-ads-advanced-js" type="checkbox" value="1" name="'.ADVADS_SLUG.'[advanced-js]" '.checked( $checked, 1, false ).'>';
		echo '<p class="description">'. sprintf( __( 'Enable advanced JavaScript functions (<a href="%s" target="_blank">here</a>). Some features and add-ons might override this setting if they need features from this file.', 'advanced-ads' ), ADVADS_URL . 'javascript-functions/#utm_source=advanced-ads&utm_medium=link&utm_campaign=settings' ) .'</p>';
	}

	/**
	 * render setting for content injection protection
	 *
	 * @since 1.4.1
	 */
	public function render_settings_content_injection_everywhere(){
		$options = Advanced_Ads::get_instance()->options();
		$everywhere = ( isset($options['content-injection-everywhere']) ) ? true : false;

		echo '<input id="advanced-ads-injection-everywhere" type="checkbox" value="true" name="'.ADVADS_SLUG.'[content-injection-everywhere]" '.checked( $everywhere, true, false ).'>';
		echo '<p class="description">'. __( 'Some plugins and themes trigger ad injection where it shouldn’t happen. Therefore, Advanced Ads ignores injected placements on non-singular pages and outside the loop. However, this can cause problems with some themes. You can enable this option if you don’t see ads or want to enable ad injections on archive pages AT YOUR OWN RISK.', 'advanced-ads' ) .'</p>';

	}

	/**
	 * render setting for content injection priority
	 *
	 * @since 1.4.1
	 */
	public function render_settings_content_injection_priority(){
		$options = Advanced_Ads::get_instance()->options();
		$priority = ( isset($options['content-injection-priority'])) ? intval( $options['content-injection-priority'] ) : 100;

		echo '<input id="advanced-ads-content-injection-priority" type="number" value="'.$priority.'" name="'.ADVADS_SLUG.'[content-injection-priority]" size="3"/>';
		echo '<p class="description">';
		if ( $priority < 11 ) {
			echo '<span class="advads-error-message">' . __( 'Please check your post content. A priority of 10 and below might cause issues (wpautop function might run twice).', 'advanced-ads' ) . '</span><br />';
		}
		_e( 'Play with this value in order to change the priority of the injected ads compared to other auto injected elements in the post content.', 'advanced-ads' );
		echo '</p>';
	}

	/**
	 * render setting for blocking bots
	 *
	 * @since 1.4.9
	 */
	public function render_settings_block_bots(){
		$options = Advanced_Ads::get_instance()->options();
		$checked = ( ! empty($options['block-bots'])) ? 1 : 0;

		echo '<input id="advanced-ads-block-bots" type="checkbox" value="1" name="'.ADVADS_SLUG.'[block-bots]" '.checked( $checked, 1, false ).'>';
		echo '<p class="description">'. sprintf( __( 'Hide ads from crawlers, bots and empty user agents. Also prevents counting impressions for bots when using the <a href="%s" target="_blank">Tracking Add-On</a>.', 'advanced-ads' ), ADVADS_URL . 'add-ons/tracking/#utm_source=advanced-ads&utm_medium=link&utm_campaign=settings' ) .'<br/>'
					. __( 'Disabling this option only makes sense if your ads contain content you want to display to bots (like search engines) or your site is cached and bots could create a cached version without the ads.', 'advanced-ads' ) . '</p>';
	}

	/**
	 * render setting to disable notices
	 *
	 * @since 1.5.3
	 */
	public function render_settings_disabled_notices(){
		$options = Advanced_Ads::get_instance()->options();
		$checked = ( ! empty($options['disable-notices'])) ? 1 : 0;

		echo '<input id="advanced-ads-disabled-notices" type="checkbox" value="1" name="'.ADVADS_SLUG.'[disable-notices]" '.checked( $checked, 1, false ).'>';
		echo '<p class="description">'. __( 'Disable internal notices like tips, tutorials, email newsletters and update notices. Disabling notices is recommended if you run multiple blogs with Advanced Ads already.', 'advanced-ads' ) . '</p>';
	}

	/**
	* render setting for frontend prefix
	*
	* @since 1.6.8
	*/
	public function render_settings_front_prefix(){
		$options = Advanced_Ads::get_instance()->options();

		$prefix = Advanced_Ads_Plugin::get_instance()->get_frontend_prefix();
		$old_prefix = ( isset($options['id-prefix'])) ? esc_attr( $options['id-prefix'] ) : '';

		echo '<input id="advanced-ads-front-prefix" type="text" value="' .$prefix .'" name="'.ADVADS_SLUG.'[front-prefix]" />';
		// deprecated
		echo '<input type="hidden" value="' .$old_prefix .'" name="'.ADVADS_SLUG.'[id-prefix]" />';
		echo '<p class="description">'. __( 'Prefix of class or id attributes in the frontend. Change it if you don’t want <strong>ad blockers</strong> to mark these blocks as ads.<br/>You might need to <strong>rewrite css rules afterwards</strong>.', 'advanced-ads' ) .'</p>';
	}

	/**
	* render setting to remove the id from advanced ads widgets
	*
	* @since 1.6.8.2
	*/
	public function render_settings_remove_widget_id(){
		$options = Advanced_Ads::get_instance()->options();

		// is true by default if no options where previously set
		if( ! isset($options['remove-widget-id']) && $options !== array() ){
		    $remove = false;
		} elseif( $options === array() ){
		    $remove = true;
		} else {
		    $remove = true;
		}

		echo '<input id="advanced-ads-remove-widget-id" type="checkbox" ' . checked( $remove, true, false ) . ' name="'.ADVADS_SLUG.'[remove-widget-id]" />';
		echo '<p class="description">' . __( 'Remove the ID attribute from widgets in order to not make them an easy target of ad blockers.', 'advanced-ads' );

		if ( class_exists( 'q2w3_fixed_widget', false ) ) {
			echo '<br />' . __( 'If checked, the Advanced Ads Widget will not work with the fixed option of the <strong>Q2W3 Fixed Widget</strong> plugin.', 'advanced-ads' );
		}

		echo '</p>';
	}

	/**
	 * render setting to allow editors to manage ads
	 *
	 * @since 1.6.14
	 */
	public function render_settings_editors_manage_ads(){
		$options = Advanced_Ads::get_instance()->options();

		// is false by default if no options where previously set
		if( isset($options['editors-manage-ads']) && $options['editors-manage-ads'] ){
		    $allow = true;
		} else {
		    $allow = false;
		}

		echo '<input id="advanced-ads-editors-manage-ads" type="checkbox" ' . checked( $allow, true, false ) . ' name="'.ADVADS_SLUG.'[editors-manage-ads]" />';
		echo '<p class="description">'. __( 'Allow editors to also manage and publish ads.', 'advanced-ads' ) . 
			' ' . sprintf(__( 'You can assign different ad-related roles on a user basis with <a href="%s" target="_blank">Advanced Ads Pro</a>.', 'advanced-ads' ), ADVADS_URL . 'add-ons/advanced-ads-pro/#utm_source=advanced-ads&utm_medium=link&utm_campaign=settings') . '</p>';
	}

	/**
	 * render setting to add an "Advertisement" label before ads
	 *
	 */
	public function render_settings_add_custom_label(){
		$options = Advanced_Ads::get_instance()->options();

		$enabled = isset( $options['custom-label']['enabled'] );
		$label = ! empty ( $options['custom-label']['text'] ) ? esc_html( $options['custom-label']['text'] ) : _x( 'Advertisements', 'label before ads' );
		?>

		<fieldset>
			<input type="checkbox" <?php checked( $enabled, true ); ?> value="1" onclick="advads_toggle_box( this, '#advads-custom-label' );" name="<?php echo ADVADS_SLUG . '[custom-label][enabled]'; ?>" />
			<input <?php if ( ! $enabled ) echo 'style="display:none;"' ?> id="advads-custom-label" type="text" value="<?php echo $label; ?>" name="<?php echo ADVADS_SLUG . '[custom-label][text]'; ?>" />
		</fieldset>
	    <p class="description"><?php _e( 'Displayed above ads.', 'advanced-ads' ); ?>&nbsp;<a target="_blank" href="<?php echo ADVADS_URL . 'manual/advertisement-label/#utm_source=advanced-ads&utm_medium=link&utm_campaign=settings-advertisement-label'?>"><?php _e( 'Manual', 'advanced-ads' ); ?></a></p>

        <?php
	}

	/**
	* render setting 'Delete data on uninstall"
	*
	*/
	public function render_settings_uninstall_delete_data(){
		$options = Advanced_Ads::get_instance()->options();
		$enabled = ! empty( $options['uninstall-delete-data'] ); ?>

		<input type="checkbox" value="1" name="<?php echo ADVADS_SLUG; ?>[uninstall-delete-data]" <?php checked( $enabled, 1 ); ?>>
		<p class="description"><?php _e( 'Clean up all data related to Advanced Ads when removing the plugin.', 'advanced-ads' ); ?></p>
		<?php
	}

	/**
	 * sanitize plugin settings
	 *
	 * @since 1.5.1
	 * @param array $options all the options
	 */
	public function sanitize_settings($options){

		// sanitize whatever option one wants to sanitize

		if ( isset( $options['front-prefix'] ) ) {
			$options['front-prefix'] = sanitize_html_class( $options['front-prefix'], Advanced_Ads_Plugin::DEFAULT_FRONTEND_PREFIX );
		}

		$options = apply_filters( 'advanced-ads-sanitize-settings', $options );

		// check if editors can edit ads now and set the rights
		// else, remove that right
		$editor_role = get_role( 'editor' );
		if( null == $editor_role ){
		    return $options;
		}
		if( isset($options['editors-manage-ads']) && $options['editors-manage-ads'] ){
			$editor_role->add_cap( 'advanced_ads_see_interface' );
			$editor_role->add_cap( 'advanced_ads_edit_ads' );
			$editor_role->add_cap( 'advanced_ads_manage_placements' );
			$editor_role->add_cap( 'advanced_ads_place_ads' );
		} else {
			$editor_role->remove_cap( 'advanced_ads_see_interface' );
			$editor_role->remove_cap( 'advanced_ads_edit_ads' );
			$editor_role->remove_cap( 'advanced_ads_manage_placements' );
			$editor_role->remove_cap( 'advanced_ads_place_ads' );
		}

		// we need 3 states: ! isset, 1, 0
		$options['disabled-ads']['feed'] = isset( $options['disabled-ads']['feed'] ) ? 1 : 0;

		return $options;
	}

}