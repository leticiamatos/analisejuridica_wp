<select id="advads-filter-type">
	<option value="">- <?php _e( 'all ad types', 'advanced-ads' ); ?> -</option>
</select>
<select id="advads-filter-size">
	<option value="">- <?php _e( 'all ad sizes', 'advanced-ads' ); ?> -</option>
</select>
<select id="advads-filter-date">
	<option value="">- <?php _e( 'all ad dates', 'advanced-ads' ); ?> -</option>
	<option value="advads-filter-expired" style="display:none;"><?php _e( 'expired', 'advanced-ads' ); ?></option>
	<option value="advads-filter-any-exp-date" style="display:none;"><?php _e( 'any expiry date', 'advanced-ads' ); ?></option>
	<option value="advads-filter-future" style="display:none;"><?php _e( 'planned', 'advanced-ads' ); ?></option>
</select>
<select id="advads-filter-group">
	<option value="">- <?php _e( 'all ad groups', 'advanced-ads' ); ?> -</option>
</select>