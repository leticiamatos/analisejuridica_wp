<div class="error advads-admin-notice notice is-dismissible message" data-notice="<?php echo $_notice; ?>"><p><?php echo $text; ?></p></div>
