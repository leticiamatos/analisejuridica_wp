<div class="updated advads-admin-notice message notice is-dismissible" data-notice="<?php echo $_notice; ?>">
    <p><?php echo $text; ?></p>
</div>
