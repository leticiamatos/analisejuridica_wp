<thead>
    <tr>
        <th><?php _e( 'Ad Group', 'advanced-ads' ); ?></th>
        <th><?php _e( 'Details', 'advanced-ads' ); ?></th>
        <th><?php _e( 'Ads', 'advanced-ads' ); ?></th>
    </tr>
</thead>