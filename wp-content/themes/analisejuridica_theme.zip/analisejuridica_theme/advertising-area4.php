<!-- 
        'name' => __('Advertising Home - Area 4', 'html5blank'),
        'description' => __('Banner 920×100px - acima da categoria < Vídeos >', 'html5blank'),
        'id' => 'widget-adv-area-4',
 -->
 <div class="adv4 adv-area adv-default">
<?php if(!function_exists('dynamic_sidebar') || !dynamic_sidebar('widget-adv-area-4')) ?>
</div>