<!-- 
        'name' => __('Advertising Footer - Area 7', 'html5blank'),
        'description' => __('Banner 920×100px -  1ª linha acima do pré-footer categoria < Últimas Publicações, Mais Lidas e Fale Conosco >', 'html5blank'),
        'id' => 'widget-adv-area-7',
 -->
 <div class="adv7 adv-area adv-default">
<?php if(!function_exists('dynamic_sidebar') || !dynamic_sidebar('widget-adv-area-7')) ?>
</div>