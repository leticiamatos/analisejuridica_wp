<!-- sidebar -->
<aside class="sidebar col1-4" role="complementary">

	<!-- Advertising widget area 05 -->
  	<?php get_template_part('advertising', 'area9'); ?>
  	<?php get_template_part('sidebar', 'noticias'); ?>
  	<?php get_template_part('advertising', 'area10'); ?>

</aside>
<!-- /sidebar -->
