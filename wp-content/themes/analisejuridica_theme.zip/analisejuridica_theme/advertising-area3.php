<!-- 
        'name' => __('Advertising Home - Area 3', 'html5blank'),
        'description' => __('Banner 300×250px -  2ª linha abaixo da categoria < Destaque >', 'html5blank'),
        'id' => 'widget-adv-area-3',
 -->
 <div class="adv3 adv-area adv-default">

<?php if(!function_exists('dynamic_sidebar') || !dynamic_sidebar('widget-adv-area-3')) ?>
	<span class="subtitle">Publicidade</span>
</div>