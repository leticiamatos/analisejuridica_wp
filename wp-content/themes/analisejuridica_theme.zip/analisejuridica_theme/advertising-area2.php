<!-- 
        'name' => __('Advertising Home - Area 2', 'html5blank'),
        'description' => __('Banner 300×250px - 1ª linha abaixo da categoria < Destaque >', 'html5blank'),
        'id' => 'widget-adv-area-2',
 -->
 <div class="adv2 adv-area adv-default">
<?php if(!function_exists('dynamic_sidebar') || !dynamic_sidebar('widget-adv-area-2')) ?>
	<span class="subtitle">Publicidade</span>
</div>