<!-- 
        'name' => __('Advertising Sidebar - Area 10', 'html5blank'),
        'description' => __('Banner 300×250px - abaixo do box < Assuntos Relacionados >', 'html5blank'),
        'id' => 'widget-adv-area-10',
 -->
 <div class="adv10 adv-area adv-default">
<?php if(!function_exists('dynamic_sidebar') || !dynamic_sidebar('widget-adv-area-
10')) ?>
	<span class="subtitle">Publicidade</span>
</div>