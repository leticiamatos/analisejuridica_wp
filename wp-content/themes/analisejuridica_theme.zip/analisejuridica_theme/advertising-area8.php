<!-- 
        'name' => __('Advertising Footer - Area 8', 'html5blank'),
        'description' => __('Banner 920×100px - 1ª linha abaixo do pré-footer categoria < Últimas Publicações, Mais Lidas e Fale Conosco >', 'html5blank'),
        'id' => 'widget-adv-area-8',
 -->
 <div class="adv8 adv-area adv-default">
<?php if(!function_exists('dynamic_sidebar') || !dynamic_sidebar('widget-adv-area-8')) ?>
</div>