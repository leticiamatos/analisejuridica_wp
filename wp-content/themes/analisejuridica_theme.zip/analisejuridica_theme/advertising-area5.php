<!-- 
        'name' => __('Advertising Home - Area 5', 'html5blank'),
        'description' => __('Banner 300×250px -  1ª linha abaixo da categoria < Vídeos >', 'html5blank'),
        'id' => 'widget-adv-area-5',
 -->

 <div class="adv5 adv-area adv-default">
<?php if(!function_exists('dynamic_sidebar') || !dynamic_sidebar('widget-adv-area-5')) ?>
	<span class="subtitle">Publicidade</span>
</div>