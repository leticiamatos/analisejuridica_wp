<!-- 
        'name' => __('Advertising Sidebar - Area 9', 'html5blank'),
        'description' => __('Banner 300×250px - acima do box < Assuntos Relacionados >', 'html5blank'),
        'id' => 'widget-adv-area-9',
 -->
 <div class="adv9 adv-area adv-default">
<?php if(!function_exists('dynamic_sidebar') || !dynamic_sidebar('widget-adv-area-9')) ?>
	<span class="subtitle">Publicidade</span>
</div>