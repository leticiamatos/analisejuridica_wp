<!-- 
     //   'name' => __('Advertising Header - Area 1', 'html5blank'),
     //   'description' => __('Banner 920×100px - abaixo do cabeçalho', 'html5blank'),
     //   'id' => 'widget-adv-area-1',
 -->
 <div class="adv1 adv-area adv-default">
<?php if(!function_exists('dynamic_sidebar') || !dynamic_sidebar('widget-adv-area-1')) ?>
</div>
