<?php get_header(); ?>

	<main role="main">

		<section class="block_wpr main_cntt">
			<div class="block_cntt">
				<div class="col3-4 post-list">
					<h1 class="page_title">Erro 404</h1>
					<p>Página não encontrada</p>

				</div>

				<?php get_sidebar(); ?>
			</div>
		</section>
	</main>

<?php get_footer(); ?>
