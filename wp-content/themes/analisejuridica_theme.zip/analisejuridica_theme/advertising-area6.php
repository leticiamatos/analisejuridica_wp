<!-- 
        'name' => __('Advertising Home - Area 6', 'html5blank'),
        'description' => __('Banner 300×250px -  2ª linha abaixo da categoria < Destaque >', 'html5blank'),
        'id' => 'widget-adv-area-6',
 -->
 <div class="adv6 adv-area adv-default">
<?php if(!function_exists('dynamic_sidebar') || !dynamic_sidebar('widget-adv-area-6')) ?>
	<span class="subtitle">Publicidade</span>
</div>