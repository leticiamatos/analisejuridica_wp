		<section class="block_wpr prefooter">
			<div class="block_cntt">
				<!-- Advertising widget area 07 -->
			  	<?php get_template_part('advertising', 'area7'); ?>
				
				<div class="col1-3">
					<h3 class="block_title">Últimas Publicações</h3>
					<?php get_template_part('prefooter', 'tabs01'); ?>
				</div>
				<div class="col1-3">
					<h3 class="block_title">Mais Lidas</h3>
					<?php get_template_part('prefooter', 'tabs02'); ?>
				</div>
				<div class="col1-3">
					<div class="contactform_wpr">
						<h4 class="col_title">Fale Conosco</h4>
						<div class="contactform_cntt sForm">
							<form>
								<div class="form_div">
									<label>Nome:</label>
									<input type="text" class="txt" />
								</div>
								<div class="form_div">
									<label>E-mail:</label>
									<input type="text" class="txt" />
								</div>
								<div class="form_div">
									<label>Assunto:</label>
									<input type="text" class="txt" />
								</div>
								<div class="form_div">
									<label>Mensagem:</label>
									<textarea class="txt" placeholder="coloque sua mensagem"></textarea>
								</div>
								<div class="buttons">
									<div class="captcha">		
									</div>
									<input type="button" class="btn" value="Enviar" />
								</div>
							</form>
						</div>
					</div>
				</div>

				<span class="clear"></span>
	
				<!-- Advertising widget area 08 -->
			  	<?php get_template_part('advertising', 'area8'); ?>
				
			</div>
		</section>
